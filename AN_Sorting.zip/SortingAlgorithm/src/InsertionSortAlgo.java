
import java.io.IOException;

public class InsertionSortAlgo {
	public static int [] insertionSortFNn(int c[][]) throws IOException {
		int H[] = new int [c.length];
		for(int i = 0; i<c.length;i++)
			H[i] = i;
        int bestcost;
        int []H2 = new int[H.length];
        for(int i = 0;i<H.length;i++) {
            H2[i] = H[i];
        }
        int cost = 0;
        int position = 1;
        

        for (int i = 0; i<(H.length); i++) {
        	bestcost = 1000;
        	System.out.println("AN" + i);
            
            for (int j = 0;j<=i;j++) {
            	cost = 0;
                //first summation
                if(j!=0 && j!=i) {
                	for(int k  = 1; k<=j-1; k++) {
                        for(int m = j-1; m<=i-1;m++) {
                            cost = cost + c[H[k]][H[m]];
                        }
                    }
                }
                //second summation
                if(j!=0) {
                	for(int k = 0; k<=j-1; k++) {
                        cost = cost + (Math.abs(j-k)-1)*c[H[k]][H[i]];
                    }
                }
                //Third summation
                if(j!=i) {
                	for(int m = j; m<=i-1;m++) {
                        cost = cost + (Math.abs(j-m))*c[H[i]][H[m]];
                    }
                }
                System.out.println("j" + j +" " + cost);
                if(cost<bestcost) {                    
                    bestcost = cost;
                    position = j;
                    if(position!=i) {
                    	
                    	for(int jj = i-1; jj>=position;jj--) {
                    		System.out.println("position " + position + "jj " + jj);
                            H2[jj+1] = H[jj];
                        }
                    }
                    H2[position] = i;
                    }
            }
           
        }
        for(int i = 0;i<c.length;i++)
        	H2[i]+=1;
        return H2;
    } 
	public static int[][] sortMatrix(int H[], int c[][]) {
        int [][] test = new int [c.length] [c.length];
        int x = 0;
        for (int i = 0;i<c.length;i++) {
            x = H[i];
            for (int j = 0;j<c.length;j++) {
                test[i][j] = c[x - 1][H[j] - 1];
                test[j][i] = c[H[j] - 1][x - 1];
                
            }
        }
        return test;
    }
	public static void printArray(int arr[]) throws IOException
    {
        int n = arr.length;
        for (int i=0; i<n; ++i) {
        	System.out.print(arr[i] + " ");
        }
    }
	public static void printMat(int arr[][]) throws IOException
    {
        int n = arr.length;
        
        for (int i=0; i<n ; i++) {
            for (int j=0; j<n;  j++) {
            	System.out.print(arr[i][j] + " "); 
            }
            System.out.println(" "); 
        }

    }

	public static void main(String[] args) throws IOException {
		int c[][] = {
				{0,0,3,0},
				{0,0,1,3},
				{0,0,0,1},
				{0,0,1,0}
		};
		//InsertionSortAlgo i;
		printMat(c);
		System.out.println(" ");
		System.out.println("AN order using insertion sort");
		printArray(insertionSortFNn(c));
		//System.out.println(" ");
		//System.out.println("Selection Matrix");
		//printMat(sortMatrix(InsertionSortAlgo.insertionSortFNn(c),c));
		
		
		
	}
}
